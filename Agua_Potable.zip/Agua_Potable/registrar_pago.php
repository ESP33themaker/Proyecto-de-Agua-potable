<?php
include 'conexion.php';

// Obtener datos de la URL
$toma_id = isset($_GET['toma_id']) ? intval($_GET['toma_id']) : 0;
$mes = isset($_GET['mes']) ? $_GET['mes'] : '';
$monto = isset($_GET['monto']) ? floatval($_GET['monto']) : 0;

// Procesar el pago si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $toma_id = intval($_POST['toma_id']);
    $mes = $_POST['mes'];
    $monto = floatval($_POST['monto']);
    $comprobante = $_POST['comprobante'];
    
    // ID del cobrador (en un sistema real, esto vendría de la sesión del usuario)
    $id_cobrador = 1;
    
    // Iniciar transacción
    $conn->begin_transaction();
    
    try {
        // 1. Insertar el pago
        $query_pago = "INSERT INTO pagos (id_toma, fecha_pago, monto, mes_pagado, id_cobrador, comprobante) 
                       VALUES (?, NOW(), ?, ?, ?, ?)";
        
        $stmt_pago = $conn->prepare($query_pago);
        $stmt_pago->bind_param("idsis", $toma_id, $monto, $mes, $id_cobrador, $comprobante);
        $stmt_pago->execute();
        
        // 2. Actualizar el adeudo como pagado
        $query_adeudo = "UPDATE adeudos SET pagado = 1 WHERE id_toma = ? AND mes = ?";
        
        $stmt_adeudo = $conn->prepare($query_adeudo);
        $stmt_adeudo->bind_param("is", $toma_id, $mes);
        $stmt_adeudo->execute();
        
        // Confirmar transacción
        $conn->commit();
        
        $mensaje = "Pago registrado correctamente";
        $tipo_mensaje = "success";
        
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $conn->rollback();
        $mensaje = "Error al registrar el pago: " . $e->getMessage();
        $tipo_mensaje = "error";
    }
    
    $stmt_pago->close();
    $stmt_adeudo->close();
}

// Obtener información de la toma para mostrar
if ($toma_id > 0) {
    $query_toma = "SELECT t.numero_toma, u.nombre 
                   FROM tomas t 
                   JOIN usuarios u ON t.id_usuario = u.id_usuario 
                   WHERE t.id_toma = ?";
    $stmt = $conn->prepare($query_toma);
    $stmt->bind_param("i", $toma_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $toma_info = $result->fetch_assoc();
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Pago - Sistema de Agua</title>
    <style>
        body {
            background-color: #121212;
            color: #fff;
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #ff3b3b;
        }
        .form-container {
            background-color: #1f1f1f;
            border-radius: 10px;
            padding: 20px;
            margin: 20px auto;
            max-width: 500px;
            text-align: left;
        }
        .info-group {
            margin-bottom: 15px;
            padding: 10px;
            background-color: #2a2a2a;
            border-radius: 5px;
        }
        .label {
            color: #ff3b3b;
            font-weight: bold;
        }
        input, button {
            padding: 10px;
            border-radius: 8px;
            margin: 5px 0;
            width: 100%;
            box-sizing: border-box;
        }
        input {
            background-color: #2a2a2a;
            color: #fff;
            border: 2px solid #ff3b3b;
        }
        button {
            background-color: #ff3b3b;
            color: #fff;
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
        }
        button:hover {
            background-color: #fff;
            color: #ff3b3b;
        }
        .success {
            color: #0f0;
            padding: 10px;
            background-color: #1f1f1f;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #ff3b3b;
            padding: 10px;
            background-color: #1f1f1f;
            border-radius: 5px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <h1>Registrar Pago</h1>
    
    <div class="form-container">
        <?php if (isset($mensaje)): ?>
            <div class="<?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
            <a href="PagosMensuales.php" style="color: #ff3b3b; text-decoration: none; font-weight: bold;">← Volver a Consulta de Pagos</a>
        <?php else: ?>
            <?php if ($toma_info): ?>
                <div class="info-group">
                    <span class="label">Toma:</span> <?php echo htmlspecialchars($toma_info['numero_toma']); ?>
                </div>
                <div class="info-group">
                    <span class="label">Propietario:</span> <?php echo htmlspecialchars($toma_info['nombre']); ?>
                </div>
                <div class="info-group">
                    <span class="label">Mes:</span> <?php echo date('F Y', strtotime($mes)); ?>
                </div>
                <div class="info-group">
                    <span class="label">Monto:</span> $<?php echo number_format($monto, 2); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <input type="hidden" name="toma_id" value="<?php echo $toma_id; ?>">
                <input type="hidden" name="mes" value="<?php echo $mes; ?>">
                <input type="hidden" name="monto" value="<?php echo $monto; ?>">
                
                <label for="comprobante" class="label">Número de Comprobante:</label>
                <input type="text" id="comprobante" name="comprobante" placeholder="Ej: COMP-001" required>
                
                <button type="submit">Registrar Pago</button>
            </form>
            
            <a href="PagosMensuales.php" style="color: #ff3b3b; text-decoration: none; font-weight: bold; display: block; margin-top: 15px;">← Cancelar y Volver</a>
        <?php endif; ?>
    </div>
</body>
</html>