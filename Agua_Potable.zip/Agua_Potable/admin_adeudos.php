<?php
include 'conexion.php';

// Consulta simplificada para obtener tomas con adeudos
$query = "SELECT 
            t.numero_toma,
            u.nombre AS propietario,
            COUNT(a.id_adeudo) AS meses_adeudados,
            SUM(CASE WHEN a.pagado = 0 THEN a.monto ELSE 0 END) AS total_adeudado
          FROM tomas t
          JOIN usuarios u ON t.id_usuario = u.id_usuario
          LEFT JOIN adeudos a ON t.id_toma = a.id_toma
          WHERE t.estado = 'ACTIVA'
          GROUP BY t.id_toma, t.numero_toma, u.nombre
          HAVING total_adeudado > 0
          ORDER BY total_adeudado DESC";

$result = $conn->query($query);

// Calcular total general
$query_total = "SELECT 
                 SUM(CASE WHEN a.pagado = 0 THEN a.monto ELSE 0 END) AS total_general
               FROM tomas t
               LEFT JOIN adeudos a ON t.id_toma = a.id_toma
               WHERE t.estado = 'ACTIVA'";

$result_total = $conn->query($query_total);
$total_general = $result_total->fetch_assoc();

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Adeudos - Administrador</title>
    <style>
        body {
            background-color: #121212;
            color: #fff;
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #ff3b3b;
        }
        .resumen {
            background-color: #1f1f1f;
            border-radius: 10px;
            padding: 20px;
            margin: 20px auto;
            max-width: 400px;
        }
        .total-general {
            font-size: 1.5em;
            color: #ff3b3b;
            font-weight: bold;
            margin: 10px 0;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #1f1f1f;
            border-radius: 10px;
            overflow: hidden;
        }
        table th, table td {
            padding: 12px;
            border-bottom: 1px solid #333;
            text-align: center;
        }
        table th {
            background-color: #ff3b3b;
            color: #fff;
        }
        .menu {
            margin: 20px 0;
        }
        .menu a {
            display: inline-block;
            margin: 10px;
            padding: 12px 20px;
            background-color: #1f1f1f;
            color: #ff3b3b;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
        }
        .menu a:hover {
            background-color: #ff3b3b;
            color: #fff;
        }
        .deuda-alta {
            color: #ff3b3b;
            font-weight: bold;
        }
        .deuda-media {
            color: #ffa500;
            font-weight: bold;
        }
        .sin-adeudos {
            color: #0f0;
            font-style: italic;
        }
    </style>
</head>
<body>
    <h1>Reporte de Adeudos - Administrador</h1>
    
    <div class="menu">
        <a href="ConsultaNumero.php">Búsqueda de Tomas</a>
        <a href="PagosMensuales.php">Consulta de Pagos</a>
        <a href="admin_adeudos_simple.php">Reporte de Adeudos</a>
    </div>

    <!-- Resumen general -->
    <div class="resumen">
        <h3>Total General Adeudado</h3>
        <div class="total-general">
            $<?php echo number_format($total_general['total_general'], 2); ?>
        </div>
    </div>

    <!-- Tabla simplificada de adeudos -->
    <table>
        <thead>
            <tr>
                <th>N° Toma</th>
                <th>Propietario</th>
                <th>Meses Adeudados</th>
                <th>Total Adeudado</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while($toma = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($toma['numero_toma']); ?></td>
                        <td><?php echo htmlspecialchars($toma['propietario']); ?></td>
                        <td>
                            <?php if ($toma['meses_adeudados'] > 0): ?>
                                <span class="deuda-alta"><?php echo $toma['meses_adeudados']; ?> meses</span>
                            <?php else: ?>
                                <span class="sin-adeudos">0 meses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($toma['total_adeudado'] > 0): ?>
                                <?php
                                $clase_deuda = 'deuda-alta';
                                if ($toma['total_adeudado'] <= 200) {
                                    $clase_deuda = 'deuda-media';
                                }
                                ?>
                                <span class="<?php echo $clase_deuda; ?>">
                                    $<?php echo number_format($toma['total_adeudado'], 2); ?>
                                </span>
                            <?php else: ?>
                                <span class="sin-adeudos">$0.00</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center; padding: 20px;">
                        <span class="sin-adeudos">¡Excelente! No hay adeudos pendientes.</span>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>