<?php
// Incluir la conexión a la base de datos
include 'conexion.php';

// Obtener todas las tomas activas para el selector
$query_tomas = "SELECT t.id_toma, t.numero_toma, u.nombre 
                FROM tomas t 
                JOIN usuarios u ON t.id_usuario = u.id_usuario 
                WHERE t.estado = 'ACTIVA' 
                ORDER BY t.numero_toma";
$result_tomas = $conn->query($query_tomas);

$tomas = [];
while ($row = $result_tomas->fetch_assoc()) {
    $tomas[] = $row;
}

// Procesar consulta si se envió el formulario
$adeudos = [];
$toma_seleccionada = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toma_id'])) {
    $toma_id = intval($_POST['toma_id']);
    
    // Obtener información de la toma seleccionada
    $query_toma = "SELECT t.*, u.nombre, u.telefono, u.direccion 
                   FROM tomas t 
                   JOIN usuarios u ON t.id_usuario = u.id_usuario 
                   WHERE t.id_toma = ?";
    $stmt = $conn->prepare($query_toma);
    $stmt->bind_param("i", $toma_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $toma_seleccionada = $result->fetch_assoc();
    $stmt->close();
    
    // Obtener los adeudos de esta toma
    $query_adeudos = "SELECT a.*, p.fecha_pago, p.comprobante 
                      FROM adeudos a 
                      LEFT JOIN pagos p ON a.id_toma = p.id_toma AND a.mes = p.mes_pagado 
                      WHERE a.id_toma = ? 
                      ORDER BY a.mes DESC";
    $stmt = $conn->prepare($query_adeudos);
    $stmt->bind_param("i", $toma_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $adeudos[] = $row;
    }
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Pagos Mensuales - Agua Potable</title>
    <style>
        body {
            background-color: #121212;
            color: #fff;
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #ff3b3b;
        }
        .menu a {
            display: inline-block;
            margin: 15px;
            padding: 15px 25px;
            background-color: #1f1f1f;
            color: #ff3b3b;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
        }
        .menu a:hover {
            background-color: #ff3b3b;
            color: #fff;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #1f1f1f;
            border-radius: 10px;
            overflow: hidden;
        }
        table th, table td {
            padding: 12px;
            border-bottom: 1px solid #333;
            text-align: left;
        }
        table th {
            background-color: #ff3b3b;
            color: #fff;
            text-align: center;
        }
        .table-boton {
            display: inline-block;
            margin: 2px;
            padding: 5px 10px;
            background-color: #ff3b3b;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }
        .table-boton:hover {
            background-color: #fff;
            color: #ff3b3b;
        }
        .selector {
            margin-top: 25px;
            padding: 20px;
            background-color: #1f1f1f;
            border-radius: 10px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        select {
            padding: 10px;
            border-radius: 8px;
            background-color: #1f1f1f;
            color: #ff3b3b;
            border: 2px solid #ff3b3b;
            min-width: 300px;
            margin: 10px 0;
        }
        button {
            padding: 10px 20px;
            background-color: #ff3b3b;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
        }
        button:hover {
            background-color: #fff;
            color: #ff3b3b;
        }
        .info-toma {
            background-color: #1f1f1f;
            border-radius: 10px;
            padding: 15px;
            margin: 20px auto;
            max-width: 800px;
            text-align: left;
        }
        .info-group {
            margin-bottom: 10px;
            padding: 8px;
            background-color: #2a2a2a;
            border-radius: 5px;
        }
        .label {
            color: #ff3b3b;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Consulta de Pagos Mensuales</h1>

    <div class="selector">
        <form method="POST" action="">
            <label for="toma"><strong>Seleccionar Toma de Agua:</strong></label>
            <br><br>
            <select id="toma" name="toma_id">
                <option value="">-- Seleccionar toma --</option>
                <?php foreach ($tomas as $toma): ?>
                    <option value="<?php echo $toma['id_toma']; ?>" 
                        <?php echo (isset($_POST['toma_id']) && $_POST['toma_id'] == $toma['id_toma']) ? 'selected' : ''; ?>>
                        Toma <?php echo htmlspecialchars($toma['numero_toma']); ?> - <?php echo htmlspecialchars($toma['nombre']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <br><br>
            <button type="submit">Consultar</button>
        </form>
    </div>

    <?php if ($toma_seleccionada): ?>
    <div class="info-toma">
        <h2>Información de la Toma</h2>
        <div class="info-group">
            <span class="label">Número de Toma:</span> <?php echo htmlspecialchars($toma_seleccionada['numero_toma']); ?>
        </div>
        <div class="info-group">
            <span class="label">Propietario:</span> <?php echo htmlspecialchars($toma_seleccionada['nombre']); ?>
        </div>
        <div class="info-group">
            <span class="label">Teléfono:</span> <?php echo htmlspecialchars($toma_seleccionada['telefono']); ?>
        </div>
        <div class="info-group">
            <span class="label">Dirección:</span> <?php echo htmlspecialchars($toma_seleccionada['direccion']); ?>
        </div>
    </div>
    <?php endif; ?>

    <div id="tablaPagos">
        <?php if (!empty($adeudos)): ?>
            <h2>Historial de Pagos y Adeudos</h2>
            <table>
                <tr>
                    <th>Mes</th>
                    <th>Monto</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
                <?php foreach ($adeudos as $adeudo): ?>
                    <?php
                    $fecha = new DateTime($adeudo['mes']);
                    $mesNombre = $fecha->format('F Y');
                    $mesFormateado = ucfirst($mesNombre);
                    ?>
                    <tr>
                        <td style="text-align: center;"><?php echo $mesFormateado; ?></td>
                        <td style="text-align: center;">$<?php echo number_format($adeudo['monto'], 2); ?></td>
                        <td style="text-align: center; color: <?php echo $adeudo['pagado'] ? '#0f0' : '#ff3b3b'; ?>;">
                            <?php echo $adeudo['pagado'] ? 'Pagado' : 'Pendiente'; ?>
                        </td>
                        <td style="text-align: center;">
                            <?php if (!$adeudo['pagado']): ?>
                                <a href="registrar_pago.php?toma_id=<?php echo $toma_seleccionada['id_toma']; ?>&mes=<?php echo $adeudo['mes']; ?>&monto=<?php echo $adeudo['monto']; ?>" class="table-boton">Pagar</a>
                            <?php endif; ?>
                            <a href="#" class="table-boton" onclick="verDetallePago(<?php echo $toma_seleccionada['id_toma']; ?>, '<?php echo $adeudo['mes']; ?>')">Ver</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <p style="color: #ff3b3b; margin-top: 20px;">No se encontraron registros de pagos o adeudos para esta toma.</p>
        <?php endif; ?>
    </div>

    <script>
        function verDetallePago(idToma, mes) {
            // En un sistema real, aquí harías una petición AJAX para obtener los detalles
            // Por ahora, mostramos un alert con la información básica
            const fecha = new Date(mes);
            const mesNombre = fecha.toLocaleString('es-ES', { month: 'long', year: 'numeric' });
            const mesFormateado = mesNombre.charAt(0).toUpperCase() + mesNombre.slice(1);
            
            alert(`Detalles del mes:\n\nToma: ${idToma}\nMes: ${mesFormateado}\n\nEn un sistema real, aquí se mostrarían los detalles completos del pago.`);
        }
    </script>

</body>
</html>