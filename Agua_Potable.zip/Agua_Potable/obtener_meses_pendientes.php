<?php
include 'conexion.php';

header('Content-Type: application/json');

$toma_id = isset($_GET['toma_id']) ? intval($_GET['toma_id']) : 0;

if ($toma_id <= 0) {
    echo json_encode(['error' => 'ID de toma no válido']);
    exit;
}

// Obtener los meses pendientes ordenados por fecha (más antiguo primero)
$query = "SELECT mes, monto 
          FROM adeudos 
          WHERE id_toma = ? AND pagado = 0 
          ORDER BY mes ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $toma_id);
$stmt->execute();
$result = $stmt->get_result();

$meses = [];
while($row = $result->fetch_assoc()) {
    $meses[] = $row;
}

$stmt->close();
$conn->close();

if (empty($meses)) {
    echo json_encode(['error' => 'No hay meses pendientes para esta toma']);
} else {
    echo json_encode(['meses' => $meses]);
}
?>