<?php
include 'conexion.php';

// Inicializar variables
$mensaje = '';
$tipo_mensaje = '';
$comprobante_generado = '';
$datos_pago = [];

// Verificar si ya hay una sesión de cobrador iniciada
session_start();
if (!isset($_SESSION['id_cobrador'])) {
    // Si no hay sesión, usar un cobrador por defecto (ID 11)
    $_SESSION['id_cobrador'] = 11;
    $_SESSION['nombre_cobrador'] = 'Pedro González Reyes';
}

// Procesar el registro de pago
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registrar_pago'])) {
    $toma_id = intval($_POST['toma_id']);
    $mes_pago = $_POST['mes_pago'];
    $monto = floatval($_POST['monto']);
    
    // Verificar que el monto sea positivo
    if ($monto <= 0) {
        $mensaje = "Error: El monto debe ser mayor a cero.";
        $tipo_mensaje = "error";
    } else {
        // Iniciar transacción
        $conn->begin_transaction();
        
        try {
            // 1. Verificar si el mes ya está pagado
            $query_verificar = "SELECT pagado FROM adeudos WHERE id_toma = ? AND mes = ?";
            $stmt = $conn->prepare($query_verificar);
            $stmt->bind_param("is", $toma_id, $mes_pago);
            $stmt->execute();
            $result = $stmt->get_result();
            $adeudo = $result->fetch_assoc();
            
            if ($adeudo && $adeudo['pagado'] == 1) {
                throw new Exception("Este mes ya está pagado.");
            }
            
            // 2. Verificar que no haya meses anteriores pendientes
            $query_meses_pendientes = "SELECT MIN(mes) as mes_antiguo 
                                       FROM adeudos 
                                       WHERE id_toma = ? AND pagado = 0 AND mes < ?";
            $stmt2 = $conn->prepare($query_meses_pendientes);
            $stmt2->bind_param("is", $toma_id, $mes_pago);
            $stmt2->execute();
            $result2 = $stmt2->get_result();
            $mes_antiguo = $result2->fetch_assoc();
            
            if ($mes_antiguo && $mes_antiguo['mes_antiguo']) {
                $fecha_antigua = date('F Y', strtotime($mes_antiguo['mes_antiguo']));
                throw new Exception("No se pueden adelantar pagos. Existe un adeudo pendiente de $fecha_antigua");
            }
            
            // 3. Generar número de comprobante
            $anio_actual = date('Y');
            $query_ultimo_comprobante = "SELECT comprobante FROM pagos 
                                         WHERE comprobante LIKE 'COMP-$anio_actual-%' 
                                         ORDER BY id_pagos DESC LIMIT 1";
            $result3 = $conn->query($query_ultimo_comprobante);
            
            if ($result3->num_rows > 0) {
                $ultimo = $result3->fetch_assoc();
                $ultimo_numero = intval(substr($ultimo['comprobante'], -3));
                $nuevo_numero = str_pad($ultimo_numero + 1, 3, '0', STR_PAD_LEFT);
            } else {
                $nuevo_numero = '001';
            }
            
            $comprobante = "COMP-$anio_actual-$nuevo_numero";
            
            // 4. Insertar el pago
            $query_pago = "INSERT INTO pagos (id_toma, fecha_pago, monto, mes_pagado, id_cobrador, comprobante) 
                           VALUES (?, NOW(), ?, ?, ?, ?)";
            
            $stmt3 = $conn->prepare($query_pago);
            $id_cobrador = $_SESSION['id_cobrador'];
            $stmt3->bind_param("idsis", $toma_id, $monto, $mes_pago, $id_cobrador, $comprobante);
            $stmt3->execute();
            
            // 5. Actualizar el adeudo como pagado
            $query_adeudo = "UPDATE adeudos SET pagado = 1 WHERE id_toma = ? AND mes = ?";
            
            $stmt4 = $conn->prepare($query_adeudo);
            $stmt4->bind_param("is", $toma_id, $mes_pago);
            $stmt4->execute();
            
            // 6. Obtener información para el comprobante
            $query_info = "SELECT t.numero_toma, u.nombre, u.direccion, 
                                  ta.descripcion AS tarifa, ta.costo_mensual
                           FROM tomas t
                           JOIN usuarios u ON t.id_usuario = u.id_usuario
                           LEFT JOIN tarifas ta ON t.id_tarifa = ta.id_tarifa
                           WHERE t.id_toma = ?";
            
            $stmt5 = $conn->prepare($query_info);
            $stmt5->bind_param("i", $toma_id);
            $stmt5->execute();
            $result_info = $stmt5->get_result();
            $datos_pago = $result_info->fetch_assoc();
            $datos_pago['comprobante'] = $comprobante;
            $datos_pago['fecha_pago'] = date('d/m/Y');
            $datos_pago['mes_pagado'] = date('F Y', strtotime($mes_pago));
            $datos_pago['monto'] = $monto;
            $datos_pago['cobrador'] = $_SESSION['nombre_cobrador'];
            
            // Confirmar transacción
            $conn->commit();
            
            $mensaje = "Pago registrado exitosamente. Comprobante: $comprobante";
            $tipo_mensaje = "success";
            $comprobante_generado = $comprobante;
            
        } catch (Exception $e) {
            // Revertir transacción en caso de error
            $conn->rollback();
            $mensaje = "Error: " . $e->getMessage();
            $tipo_mensaje = "error";
        }
    }
}

// Obtener tomas activas para el formulario
$query_tomas = "SELECT t.id_toma, t.numero_toma, u.nombre 
                FROM tomas t 
                JOIN usuarios u ON t.id_usuario = u.id_usuario 
                WHERE t.estado = 'ACTIVA' 
                ORDER BY t.numero_toma";
$result_tomas = $conn->query($query_tomas);

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Pagos - Sistema de Agua</title>
    <style>
        body {
            background-color: #121212;
            color: #fff;
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #ff3b3b;
        }
        .menu {
            margin: 20px 0;
        }
        .menu a {
            display: inline-block;
            margin: 10px;
            padding: 12px 20px;
            background-color: #1f1f1f;
            color: #ff3b3b;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
        }
        .menu a:hover {
            background-color: #ff3b3b;
            color: #fff;
        }
        .form-container {
            background-color: #1f1f1f;
            border-radius: 10px;
            padding: 20px;
            margin: 20px auto;
            max-width: 500px;
            text-align: left;
        }
        .info-group {
            margin-bottom: 15px;
            padding: 10px;
            background-color: #2a2a2a;
            border-radius: 5px;
        }
        .label {
            color: #ff3b3b;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        select, input {
            padding: 10px;
            border-radius: 8px;
            margin: 5px 0;
            width: 100%;
            box-sizing: border-box;
            background-color: #2a2a2a;
            color: #fff;
            border: 2px solid #ff3b3b;
        }
        button {
            padding: 10px 20px;
            background-color: #ff3b3b;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
            width: 100%;
            margin-top: 10px;
        }
        button:hover {
            background-color: #fff;
            color: #ff3b3b;
        }
        .success {
            color: #0f0;
            padding: 10px;
            background-color: #1f1f1f;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #ff3b3b;
            padding: 10px;
            background-color: #1f1f1f;
            border-radius: 5px;
            margin: 10px 0;
        }
        .comprobante {
            background-color: white;
            color: black;
            padding: 20px;
            margin: 20px auto;
            max-width: 500px;
            border-radius: 10px;
            text-align: left;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .comprobante-header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .comprobante-footer {
            text-align: center;
            margin-top: 30px;
            font-style: italic;
            color: #666;
        }
        .btn-print {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px;
        }
        .btn-print:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Registro de Pagos Mensuales</h1>
    
    <div class="menu">
        <a href="ConsultaNumero.php">Búsqueda de Tomas</a>
        <a href="PagosMensuales.php">Consulta de Pagos</a>
        <a href="admin_adeudos_simple.php">Reporte de Adeudos</a>
        <a href="registro_pago.php">Registrar Pago</a>
    </div>

    <?php if ($mensaje): ?>
        <div class="<?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <?php if ($comprobante_generado && !empty($datos_pago)): ?>
        <!-- Mostrar comprobante -->
        <div class="comprobante" id="comprobante">
            <div class="comprobante-header">
                <h2 style="color: #333;">COMPROBANTE DE PAGO</h2>
                <h3 style="color: #ff3b3b;"><?php echo $datos_pago['comprobante']; ?></h3>
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Fecha de Pago:</span> 
                <?php echo $datos_pago['fecha_pago']; ?>
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Toma:</span> 
                <?php echo htmlspecialchars($datos_pago['numero_toma']); ?>
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Propietario:</span> 
                <?php echo htmlspecialchars($datos_pago['nombre']); ?>
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Dirección:</span> 
                <?php echo htmlspecialchars($datos_pago['direccion']); ?>
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Mes Pagado:</span> 
                <?php echo $datos_pago['mes_pagado']; ?>
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Tarifa:</span> 
                <?php echo htmlspecialchars($datos_pago['tarifa']); ?> - 
                $<?php echo number_format($datos_pago['costo_mensual'], 2); ?> mensual
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Monto Pagado:</span> 
                $<?php echo number_format($datos_pago['monto'], 2); ?>
            </div>
            
            <div class="info-group" style="background-color: #f5f5f5; color: #333;">
                <span style="font-weight: bold; color: #333;">Cobrador:</span> 
                <?php echo htmlspecialchars($datos_pago['cobrador']); ?>
            </div>
            
            <div class="comprobante-footer">
                <p>Gracias por su pago. Este comprobante es su constancia de pago.</p>
                <p>Sistema de Agua Potable - <?php echo date('Y'); ?></p>
            </div>
        </div>
        
        <button class="btn-print" onclick="imprimirComprobante()">Imprimir Comprobante</button>
        <a href="registro_pago.php" style="color: #ff3b3b; text-decoration: none; font-weight: bold;">
            Registrar otro pago
        </a>
        
    <?php else: ?>
        <!-- Formulario de registro -->
        <div class="form-container">
            <form method="POST" action="" id="formPago">
                <div class="info-group">
                    <label class="label">Seleccionar Toma:</label>
                    <select id="toma_id" name="toma_id" required onchange="cargarMesesPendientes()">
                        <option value="">-- Seleccionar toma --</option>
                        <?php while($toma = $result_tomas->fetch_assoc()): ?>
                            <option value="<?php echo $toma['id_toma']; ?>">
                                Toma <?php echo htmlspecialchars($toma['numero_toma']); ?> - 
                                <?php echo htmlspecialchars($toma['nombre']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="info-group">
                    <label class="label">Mes a Pagar:</label>
                    <select id="mes_pago" name="mes_pago" required disabled>
                        <option value="">-- Seleccione primero una toma --</option>
                    </select>
                </div>
                
                <div class="info-group">
                    <label class="label">Monto:</label>
                    <input type="number" id="monto" name="monto" step="0.01" min="0" required disabled>
                </div>
                
                <div id="info-adeudo" style="display: none; margin-bottom: 15px; padding: 10px; background-color: #333; border-radius: 5px;">
                    <p id="texto-info"></p>
                </div>
                
                <button type="submit" name="registrar_pago" id="btnRegistrar" disabled>
                    Registrar Pago
                </button>
            </form>
        </div>
    <?php endif; ?>

    <script>
        function cargarMesesPendientes() {
            const tomaId = document.getElementById('toma_id').value;
            const mesSelect = document.getElementById('mes_pago');
            const montoInput = document.getElementById('monto');
            const infoDiv = document.getElementById('info-adeudo');
            const textoInfo = document.getElementById('texto-info');
            const btnRegistrar = document.getElementById('btnRegistrar');
            
            if (!tomaId) {
                mesSelect.disabled = true;
                mesSelect.innerHTML = '<option value="">-- Seleccione primero una toma --</option>';
                montoInput.disabled = true;
                montoInput.value = '';
                infoDiv.style.display = 'none';
                btnRegistrar.disabled = true;
                return;
            }
            
            // Mostrar loading
            mesSelect.innerHTML = '<option value="">Cargando meses pendientes...</option>';
            mesSelect.disabled = true;
            
            // Hacer petición AJAX
            fetch(`obtener_meses_pendientes.php?toma_id=${tomaId}`)
                .then(response => response.json())
                .then(data => {
                    mesSelect.innerHTML = '<option value="">-- Seleccionar mes --</option>';
                    
                    if (data.error) {
                        mesSelect.innerHTML = `<option value="">${data.error}</option>`;
                        infoDiv.style.display = 'block';
                        textoInfo.innerHTML = `<span style="color: #ff3b3b;">${data.error}</span>`;
                        return;
                    }
                    
                    if (data.meses && data.meses.length > 0) {
                        mesSelect.disabled = false;
                        
                        data.meses.forEach(mes => {
                            const fecha = new Date(mes.mes);
                            const mesNombre = fecha.toLocaleString('es-ES', { month: 'long', year: 'numeric' });
                            const mesFormateado = mesNombre.charAt(0).toUpperCase() + mesNombre.slice(1);
                            
                            const option = document.createElement('option');
                            option.value = mes.mes;
                            option.textContent = mesFormateado;
                            option.dataset.monto = mes.monto;
                            
                            // Solo habilitar el primer mes (más antiguo)
                            if (data.meses.indexOf(mes) === 0) {
                                option.selected = true;
                                montoInput.value = mes.monto;
                                montoInput.disabled = false;
                                btnRegistrar.disabled = false;
                                
                                // Mostrar información
                                infoDiv.style.display = 'block';
                                if (data.meses.length > 1) {
                                    textoInfo.innerHTML = `<span style="color: #ffa500;">
                                        <strong>Importante:</strong> Solo se puede pagar el mes más antiguo pendiente.<br>
                                        Hay ${data.meses.length - 1} mes(es) adicionales pendientes que deberán pagarse después.
                                    </span>`;
                                } else {
                                    textoInfo.innerHTML = `<span style="color: #0f0;">
                                        Puede proceder con el pago de este mes.
                                    </span>`;
                                }
                            } else {
                                option.disabled = true;
                            }
                            
                            mesSelect.appendChild(option);
                        });
                    } else {
                        mesSelect.innerHTML = '<option value="">No hay meses pendientes</option>';
                        infoDiv.style.display = 'block';
                        textoInfo.innerHTML = '<span style="color: #0f0;">Esta toma está al corriente en sus pagos.</span>';
                        montoInput.disabled = true;
                        btnRegistrar.disabled = true;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    mesSelect.innerHTML = '<option value="">Error al cargar datos</option>';
                    infoDiv.style.display = 'block';
                    textoInfo.innerHTML = '<span style="color: #ff3b3b;">Error al cargar los meses pendientes.</span>';
                });
        }
        
        // Actualizar monto cuando se cambie el mes
        document.getElementById('mes_pago').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            if (selectedOption.dataset.monto) {
                document.getElementById('monto').value = selectedOption.dataset.monto;
            }
        });
        
        function imprimirComprobante() {
            const comprobante = document.getElementById('comprobante');
            const ventana = window.open('', '_blank');
            ventana.document.write(`
                <html>
                <head>
                    <title>Comprobante de Pago</title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 20px; }
                        .comprobante { max-width: 500px; margin: 0 auto; }
                        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; }
                        .info { margin: 10px 0; padding: 8px; background-color: #f5f5f5; }
                        .footer { text-align: center; margin-top: 30px; font-style: italic; color: #666; }
                    </style>
                </head>
                <body>
                    ${comprobante.outerHTML}
                </body>
                </html>
            `);
            ventana.document.close();
            ventana.print();
        }
    </script>
</body>
</html>