<?php
// Incluir la conexión a la base de datos
include 'conexion.php';

// Procesar búsqueda si se envió el formulario
$resultados = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buscar'])) {
    $modo = $_POST['modoBusqueda'];
    $termino = $_POST['inputBuscar'];
    
    if ($modo === 'numero') {
        // Buscar por número de toma
        $query = "SELECT t.*, u.nombre, u.telefono, u.direccion 
                  FROM tomas t 
                  JOIN usuarios u ON t.id_usuario = u.id_usuario 
                  WHERE t.numero_toma LIKE ? AND t.estado = 'ACTIVA'";
    } else {
        // Buscar por nombre del propietario
        $query = "SELECT t.*, u.nombre, u.telefono, u.direccion 
                  FROM tomas t 
                  JOIN usuarios u ON t.id_usuario = u.id_usuario 
                  WHERE u.nombre LIKE ? AND t.estado = 'ACTIVA'";
    }
    
    $stmt = $conn->prepare($query);
    $terminoBusqueda = "%$termino%";
    $stmt->bind_param("s", $terminoBusqueda);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $resultados[] = $row;
    }
    
    $stmt->close();
}

// Cerrar conexión (al final del archivo)
$conn->close();
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Consultar / Búsqueda - Proyecto Agua Potable</title>
<style>
body {
background-color: #121212;
color: #fff;
font-family: Arial, sans-serif;
text-align: center;
margin: 0;
padding: 20px;
}
h1 {
color: #ff3b3b;
}
.menu a {
display: inline-block;
margin: 15px;
padding: 15px 25px;
background-color: #1f1f1f;
color: #ff3b3b;
text-decoration: none;
border-radius: 8px;
font-weight: bold;
transition: 0.3s;
}
.menu a:hover {
background-color: #ff3b3b;
color: #fff;
}
.table-boton {
display: inline-block;
margin: 2px;
padding: 5px 10px;
background-color: #ff3b3b;
color: #fff;
text-decoration: none;
border-radius: 5px;
font-weight: bold;
transition: 0.3s;
}
.table-boton:hover {
background-color: #fff;
color: #ff3b3b;
}
.controls {
display: flex;
flex-wrap: wrap;
justify-content: center;
gap: 15px;
margin-bottom: 20px;
padding: 20px;
background-color: #1f1f1f;
border-radius: 10px;
max-width: 800px;
margin-left: auto;
margin-right: auto;
}
.field {
display: flex;
flex-direction: column;
align-items: flex-start;
}
label {
margin-bottom: 5px;
color: #ff3b3b;
font-weight: bold;
}
select, input {
padding: 10px;
border-radius: 8px;
background-color: #2a2a2a;
color: #fff;
border: 2px solid #ff3b3b;
min-width: 200px;
}
button {
padding: 10px 20px;
background-color: #ff3b3b;
color: #fff;
border: none;
border-radius: 8px;
cursor: pointer;
font-weight: bold;
transition: 0.3s;
margin-top: 25px;
}
button:hover {
background-color: #fff;
color: #ff3b3b;
}
table {
width: 95%;
margin: 20px auto;
border-collapse: collapse;
background-color: #1f1f1f;
border-radius: 10px;
overflow: hidden;
}
table th, table td {
padding: 12px;
border-bottom: 1px solid #333;
text-align: left;
}
table th {
background-color: #ff3b3b;
color: #fff;
}
.card {
background-color: #1f1f1f;
border-radius: 10px;
padding: 20px;
margin: 20px auto;
max-width: 1000px;
}
</style>
</head>
<body>
<div class="container">
<header>
<h1>Consultar / Búsqueda — Tomas activas</h1>
<small style="color:#888">Cobrador: buscar por número o nombre del propietario</small>
</header>

<section class="card">
<h2 style="font-size:16px;margin:0 0 12px 0">Buscar toma</h2>

<form method="POST" action="">
<div class="controls">
<div class="field">
<label for="modoBusqueda">Modo de búsqueda</label>
<select id="modoBusqueda" name="modoBusqueda" aria-label="Modo de búsqueda">
<option value="numero" <?php echo (isset($_POST['modoBusqueda']) && $_POST['modoBusqueda'] == 'numero') ? 'selected' : ''; ?>>Número de toma</option>
<option value="nombre" <?php echo (isset($_POST['modoBusqueda']) && $_POST['modoBusqueda'] == 'nombre') ? 'selected' : ''; ?>>Nombre del propietario</option>
</select>
</div>

<div class="field" style="flex:1;min-width:200px;">
<label for="inputBuscar">Escribe número o nombre</label>
<input type="text" id="inputBuscar" name="inputBuscar" placeholder="Ej: 01717 o Juan Pérez" 
       value="<?php echo isset($_POST['inputBuscar']) ? htmlspecialchars($_POST['inputBuscar']) : ''; ?>" 
       aria-label="Campo de búsqueda">
</div>

<button type="submit" name="buscar">Buscar</button>
</div>
</form>

<?php if (!empty($resultados)): ?>
<div style="margin-top: 30px;">
<h3>Resultados de la búsqueda:</h3>
<table>
<thead>
<tr>
<th>Número de Toma</th>
<th>Propietario</th>
<th>Teléfono</th>
<th>Dirección</th>
<th>Estado</th>
<th>Acciones</th>
</tr>
</thead>
<tbody>
<?php foreach ($resultados as $toma): ?>
<tr>
<td><?php echo htmlspecialchars($toma['numero_toma']); ?></td>
<td><?php echo htmlspecialchars($toma['nombre']); ?></td>
<td><?php echo htmlspecialchars($toma['telefono']); ?></td>
<td><?php echo htmlspecialchars($toma['direccion']); ?></td>
<td><?php echo htmlspecialchars($toma['estado']); ?></td>
<td>
<a href="detalles_toma.php?id=<?php echo $toma['id_toma']; ?>" class="table-boton">Ver Detalles</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
<p style="color: #ff3b3b; margin-top: 20px;">No se encontraron tomas activas que coincidan con la búsqueda.</p>
<?php endif; ?>
</section>
</div>
</body>
</html>